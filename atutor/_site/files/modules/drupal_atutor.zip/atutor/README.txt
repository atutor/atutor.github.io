Overview
---------

This is an integration module for ATutor

Requirements
------------
* ATutor version 1.5 or above
* Drupal 4.5.x or later

For installation instructions please see INSTALL.txt

Author
-------

Cas Nuy <Cas@nuy.info>
