/************************************************************************/
/* pnATutor       (/pndocs/readme.txt)                                */
/************************************************************************/

The pnATutor hack for Postnuke is very simple and requires no tables in the DB.

Tested with :
Postnuke 0.760
ATutor 1.4/1.5
Linux/Windows

Location of the ATutor installation is not important.


INSTALLATION
======================
0.  Install ATutor stand alone and verify it is working correct.
1.  Unzip the contents to your /modules directory.
2.  Copy ATutor\*.* to the root of your ATutor directory
3.  Initialise & activate the module
4.  Link the module into a menu block as : {pnATutor}
