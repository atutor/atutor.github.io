<?php
define('_AMOUNT','Amount of Courses to show :');
define('_PNATUTORMODULE','Go to ATutor');
define('_USE_JAVA','Use Java script in Block (y/n) : ');
define('_LOAD_JAVA','Load Java Sript (y/n) : ');
define('_TRIM','Trim titles to X  ( 0 = no trim) :');
define('_ENROLLED','Show only Courses already Enrolled (y/n) : ');
?>
