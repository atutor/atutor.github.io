# sql file for hello world module



INSERT INTO `language_text` VALUES ('en', '_module','google_talk','Google Talk',NOW(),'');
