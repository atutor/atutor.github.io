# sql file for sitemapxml module v0.4


INSERT INTO `language_text` VALUES ('en', '_module','sitemapxml','XML SiteMap',NOW(),'');
