<?php
// WordPress database access information.
// Set the values below to those needed to access your Wordpress database
// Wordpress needs to be installed in the same server as ATutor

define('WP_DB_USER',	'');           # enter your mysql database user name
define('WP_DB_PWD',	'');           # enter your mysql database password
define('WP_DB_NAME',	'wordpress');         #default "wordpress"
define('WP_DB_PREFIX',	'wp_');            #default "wp_"
define('WP_DB_HOST',	'localhost');      #default "localhost"
define('WP_DB_PORT',	'3600');           #default "3600"

?>
