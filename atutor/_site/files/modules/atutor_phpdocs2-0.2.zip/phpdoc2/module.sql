# sql file for PHPDoc module

INSERT INTO `language_text` VALUES ('en', '_module','phpdoc2','PHPDocumentor',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_msgs','AT_ERROR_API_NOT_WRITABLE','To install the API, the <code>%s</code> %s must be set to writeable. Use the command <kbd>chmod a+w %s</kbd> on Unix machines, while on Windows the web server must have write permissions on that directory.',NOW(),'');

