
        <div id="settings">
        It is highly recommended that you use the registered on <a href="https://www.talkr.im/">talkr.im</a> server account only within the ATutor chat client to avoid loss of data or other undesirable consequences.<br/>
		
		Please see <a href="<?php echo $_base_path; ?>mods/chat_new/ATutor_XMPP_Chat_READ_ME_2.0.pdf" target="_blank">the helping document</a> for more details.<br/><br/>        	
        </div>
