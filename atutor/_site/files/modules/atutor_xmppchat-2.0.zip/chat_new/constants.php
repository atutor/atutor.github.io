<?php
if (!defined('AT_INCLUDE_PATH')) { exit; }

$XMPP_CONSOLE_ENABLED = 0;

$BOSH_CONNECTION_MANAGER = "http://bosh.metajack.im:5280/xmpp-httpbind";

$INBOX_ONE_TIME_LOAD = 10;
$CHAT_HISTORY_ONE_TIME_LOAD = 15;
$CHAT_HISTORY_INITIAL_SHOW_MESSAGES = 10;

?>