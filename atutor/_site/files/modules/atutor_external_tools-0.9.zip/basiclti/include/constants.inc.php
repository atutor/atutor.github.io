<?php

define('AT_BL_BASENAME',        'mods/basiclti/');
define('AT_BL_BASE',            AT_INCLUDE_PATH.'../mods/basiclti/');
define('AT_BL_INCLUDE',         AT_BL_BASE.'include/');
define('AT_BL_CONTENT_DIR',     AT_CONTENT_DIR.'basiclti/');
?>
