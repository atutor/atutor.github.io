<?php

function adobe_connect_cron() {

	global $db;

        // TODO
        // create adobe_connect_tasks to manage pending server petitions
        // read adobe_connect_tasks
        // while !feof
            // send petition to ac server

}

?>
