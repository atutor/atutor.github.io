<?php
if (!defined("LOADED_AS_MODULE")) {
    die ("You can't access this file directly...");
}
if (!pnLocalReferer()) {
    die ("You can't access this file from and external site...");
}
$guest=pnModGetVar('pnNetjuke', '_guest');
$home = pnGetBaseURL() ;
$home .= "user.php?op=loginscreen&module=NS-User" ;
if (!pnUserLoggedIn()) {
if ($guest<1){
pnRedirect($home) ;

}
}
if ($url=="") {
die ("Wrong method of calling this module use {} instead of []..");
}
include("header.php");
echo "<iframe id='pnATutor' src='$url'  width='100%' height='800' marginwidth=0 marginheight=0 frameborder=0 ></iframe>";
include("footer.php");
?>
