<?php
/************************************************************************/
/* pnATutor                  (Version.php)                             */
/************************************************************************/
$modversion['name'] = 'pnATutor';  //Module name
$modversion['version'] = '1.2';  //Version number
$modversion['description'] = 'Postnuke ATutor Hack';  //Module description
$modversion['credits'] = 'pndocs/credits.txt';  //Credits file
$modversion['help'] = 'pndocs/readme.txt';  //Help file
$modversion['changelog'] = 'pndocs/changelog.txt';  //Change log file
$modversion['license'] = 'pndocs/license.txt';  //License file
$modversion['official'] = '0';  //Official PostNuke Approved Module 1 = yes, 0 = no
$modversion['author'] = 'Cas Nuy';  //Author
$modversion['contact'] = 'Cas@nuy.info';  //The authors website or contact email address
$modversion['admin'] = 1;
$modversion['securityschema'] = array('pnATutor::' => '::');

?>
