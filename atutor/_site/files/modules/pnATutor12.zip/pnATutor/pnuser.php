<?php
function pnATutor_user_main() {
$loc1=pnModGetVar('pnATutor', '_loc');
$loc=trim($loc1);
$window=pnModGetVar('pnATutor', '_window');
$wrap=pnModGetVar('pnATutor', '_wrap');
$guest=pnModGetVar('pnATutor', '_guest');
$users=pnModGetVar('pnATutor', '_users');
$db=pnModGetVar('pnATutor', '_db');

$username=pnUserGetVar(uname);
$usermail=pnUserGetVar(email);

if (!pnUserLoggedIn()) {
	if ($guest == 1){
		$username= "Guest" ;
	} else {
		$username= "" ;
	}
}
$home = pnGetBaseURL() ;
$parm = $username ;
$parm .="|";
$parm .= $usermail;
$parm .="|";
$parm .= $users;
$parm .="|";
$parm .= $db;
$parm .="|";
$parm .= $home ;
$parm .="|";
$parm .= 0;
$parm .="|";
$parm .= 0 ;

$check=md5($parm) ;

$url="$loc/index_pn.php?parm=$parm%26check=$check";

if ($window == 1 ) {
$url="$loc/index_pn.php?parm=$parm&check=$check";
Header('Location: '.$url );

} else {
if ($wrap != ''){
	Header ("Location: modules.php?op=modload&name=PostWrap&file=index&page=$url");
} else {
	Header ("Location: modules.php?op=modload&name=pnATutor&file=index&url=$url");
}
}

exit;
}

function pnATutor_user_view() {
$cid = pnVarCleanFromInput('id');

$loc1=pnModGetVar('pnATutor', '_loc');
$loc=trim($loc1);
$window=pnModGetVar('pnATutor', '_window');
$wrap=pnModGetVar('pnATutor', '_wrap');
$guest=pnModGetVar('pnATutor', '_guest');
$users=pnModGetVar('pnATutor', '_users');
$db=pnModGetVar('pnATutor', '_db');

$username=pnUserGetVar(uname);
$usermail=pnUserGetVar(email);

if (!pnUserLoggedIn()) {
	if ($guest == 1){
		$username= "Guest" ;
	} else {
		$username= "" ;
	}
}
$home = pnGetBaseURL() ;
$parm = $username ;
$parm .="|";
$parm .= $usermail;
$parm .="|";
$parm .= $users;
$parm .="|";
$parm .= $db;
$parm .="|";
$parm .= $home ;
$parm .="|";
$parm .= $cid;
$parm .="|";
$parm .= 0 ;

$check=md5($parm) ;

$url="$loc/index_pn.php?parm=$parm%26check=$check";

if ($window == 1 ) {
$url="$loc/index_pn.php?parm=$parm&check=$check";
Header('Location: '.$url );

} else {
if ($wrap != ''){
	Header ("Location: modules.php?op=modload&name=PostWrap&file=index&page=$url");
} else {
	Header ("Location: modules.php?op=modload&name=pnATutor&file=index&url=$url");
}
}

exit;
}

?>
