/************************************************************************/
/* pnATutor       (/pndocs/readme.txt)                                */
/************************************************************************/

The pnATutor hack for Postnuke is very simple and requires no tables in the DB.

Tested with :
Postnuke 0.726
ATutor 1.3
Linux/Windows

Location of the ATutor installation is not important.


INSTALLATION
======================
0.  Install ATutor stand alone and verify it is working correct.
1.  Unzip the contents to your /modules directory.
2.  Copy ATutor\*.* to the root of your ATutor directory
3.  Go to the adminsection of ATutor (Stand alone mode), system preferences and check embedded in Postnuke
4.  Initialise & activate the module
5.  Link the module into a menu block as : {pnATutor}


TIPS
=====
In order to have the application opened in a separate New Window (full screen) do the following :
Create a Core/HTML block with the following contents :
<a href="index.php?module=pnATutor&func=main" target=_blank">ATutor</a>
Make sure that in Admin Panel you have checked the Full Screen option

