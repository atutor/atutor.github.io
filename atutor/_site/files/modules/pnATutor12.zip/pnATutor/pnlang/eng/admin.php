<?php
/************************************************************************/
/* pnNetjuke                  (lang/eng/admin.php)                      */
/************************************************************************/

/*---ADMIN-TEXT--------------------------------------------------------------*/
define("_MODSUBJECT", "The Location of the ATutor installation");
define("_MODWARNING", "Do not use the trailing slash !!!!");
define("_MODERROR", "Error message when logon fails");
define("_MODWINDOW", "Open Application Full Screen");
define("_MODWRAP", "Use PostWrap");
define("_MODDB", "Name of the ATutor-Database (for future sideblock) ");
define("_MODGUEST", "Allow Guest access ( y/n )");
define("_MODUSERS", "Create PostNuke users ( y/n )");
define("_PNATUTORNOAUTH", "You are not authorised for this action");
define("_PNATUTOR", "pnATutor 1.2");
define("_PNATUTORMODIFYCONFIG", "Modify pnATutor Configuration");
define("_PNATUTORUPDATE", "Update pnATutor Configuration");
define("_PNATUTORVERSION", "Version of ATutor (default 1.3.1) :");
/*---END-ADMIN-TEXT----------------------------------------------------------*/
?>
