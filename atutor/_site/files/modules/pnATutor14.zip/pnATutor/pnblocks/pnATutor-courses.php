<?php

$blocks_modules['pnATutor-courses'] = array (
    'func_display' => 'blocks_pnATutor_display',
    'func_add' => 'blocks_pnATutor_add',
    'func_update' => 'blocks_pnATutor_update',
    'func_edit' => 'blocks_pnATutor_edit',
    'text_type' => 'pnATutor-courses',
    'text_type_long' => 'Available courses within ATutor',
    'allow_multiple' => true,
    'form_content' => false,
    'form_refresh' => false,
    'show_preview' => true
);
addinstanceschemainfo('pnATutor-courses::', '::');

function blocks_pnATutor_display($row)
{
if (!authorised(0, 'pnATutor-courses::', '::', ACCESS_OVERVIEW)) {
	return;
}

$url = explode('|', $row['url']);
if (!$url[0]){
	$url[0] = 5;
}
if (!$url[3]){
    $url[3] = 30;
}
if (!$url[4]){
    $url[4] = 'n';
}
if (!$url[5]){
    $url[5] = 'n';
}
if (!$url[6]){
    $url[6] = 'y';
}

$amount=$url[0];
$db=$url[1];
$prefix=$url[2];
$trim = $url[3] ;
$usejava= $url[4];
$loadjava = $url[5] ;
$enrolled = $url[6] ;

$std_db = pnConfigGetVar('dbname');

$pcModInfo = pnModGetInfo(pnModGetIDFromName('pnATutor'));
$ModName = pnVarPrepForOS($pcModInfo['directory']);
if ($url[4] == 'y'){
if ($url[5] == 'y'){
$content .=  "<div id=\"overDiv\" style=\"position:absolute; visibility:hidden; z-index:1000;\"></div><script language=\"JavaScript\" src=\"modules/$ModName/pnincludes/overlib_mini.js\"><!-- overLIB (c) Erik Bosrup --></script> " ;
}
}

$content .= "<center><b>" ;
$content .= _PNATUTOR_COURSES ;
$content .= "</center></b>";

$username=pnUserGetVar(uname);


// number of Courses
$true = pnDBInit();
$true = mysql_select_db($db) or die("cannot select database: " . mysql_error()) ;
if ($url[6] == 'n'){
$result = mysql_query("select course_id, title, description from $prefix".courses."  order by course_id DESC limit ".$amount." ") or die("cannot select from table: " . mysql_error());
} else {
	if (pnUserLoggedIn()) {
		$result1 =mysql_query( "SELECT member_id FROM $prefix".members." WHERE login='$username' ");
		if (mysql_num_rows($result1)< 1){
			$userid = 0;
		}else {
			$row99 = mysql_fetch_row($result1) ;
			$userid = $row99[0];
		}

		$result = mysql_query("SELECT $prefix".courses.".course_id, title, description FROM $prefix".courses.", $prefix".course_enrollment." WHERE  $prefix".course_enrollment.".course_id = $prefix".courses.".course_id and $prefix".course_enrollment.".member_id = ".$userid." order by title limit ".$amount."  ") or die("cannot select from table: " . mysql_error());
	}
}
while (list($id, $title, $summary) = mysql_fetch_row($result)) {
    if ($trim != 0){
        if (strlen($title) > $trim) {
            $title = substr($title,0,$trim);
            $title .= "...";
        }
    }

if ($url[4] == 'y'){
     $content .="<a href=\"index.php?module=pnATutor&func=view&id=$id\" onmouseover=\"return overlib('$summary');\" onmouseout=\"return nd();\">$title</a> ";
} else {
    $content .="<a href=\"index.php?module=pnATutor&func=view&id=$id\">$title</a> ";
}

$content .= "<br>";
}

$content .= "<br>";
$url="index.php?module=pnATutor&func=main";
$urllink = _PNATUTORMODULE ;
$content .= "<b>";
$content .= "<A HREF=\"".$url."\">".$urllink."</A> " ;
$content .= "</b>";
$true = mysql_select_db($std_db) ;

$row[content]=$content;
return themesideblock($row);
}




function blocks_pnATutor_add($row)
{
$row['url'] = '5|atutor||30|n|n|y';
return $row;
}

function blocks_pnATutor_update($vars)
{
$vars['url'] = "$vars[amount]|$vars[db]|$vars[prefix]|$vars[trim]|$vars[usejava]|$vars[loadjava]|$vars[enrolled]";
return $vars;
}

function blocks_pnATutor_edit($row)
{
if (!empty($row['url'])) {
	$url = explode('|', $row['url']);
	$amount = $url[0];
	$db = $url[1];
	$prefix = $url[2];
	$trim = $url[3] ;
	$usejava = $url[4] ;
	$loadjava = $url[5];
	$enrolled= $url[6] ;
} else {
	$amount = 5;
	$db = 'atutor';
	$prefix = '';
	$trim = 30 ;
	$usejava = 'n' ;
	$loadjava = 'n';
	$enrolled = 'y';
}

$output = "<tr><td>"
    .""._PNATUTOR_DATABASE."</td><td><input type=\"text\" name=\"db\" size=\"25\" maxlength=\"25\" value=\"$db\" class=\"pn-normal\"></td></tr><tr><td>"
    .""._PNATUTOR_PREFIX."</td><td><input type=\"text\" name=\"prefix\" size=\"10\" maxlength=\"10\" value=\"$prefix\" class=\"pn-normal\"></td></tr><tr><td>"
    .""._PNATUTOR_AMOUNT."</td><td><input type=\"text\" name=\"amount\" size=\"6\" maxlength=\"255\" value=\"$amount\" class=\"pn-normal\"></td></tr><tr><td>"
    .""._PNATUTOR_ENROLLED."</td><td><input type=\"text\" name=\"enrolled\" size=\"1\" maxlength=\"1\" value=\"$enrolled\" class=\"pn-normal\"></td></tr><tr><td>"
          .""._PNATUTOR_TRIM."</td><td><input type=\"text\" name=\"trim\" size=\"2\" maxlength=\"2\" value=\"$trim\" class=\"pn-normal\"></td></tr><tr><td>"
    .""._USE_JAVA."</td><td><input type=\"text\" name=\"usejava\" size=\"1\" maxlength=\"1\" value=\"$usejava\" class=\"pn-normal\"></td></tr><tr><td>"
    .""._LOAD_JAVA."</td><td><input type=\"text\" name=\"loadjava\" size=\"1\" maxlength=\"1\" value=\"$loadjava\" class=\"pn-normal\"></td></tr><tr><td>"
    ."</td></tr>\n"  ;
return $output;
}

?>
