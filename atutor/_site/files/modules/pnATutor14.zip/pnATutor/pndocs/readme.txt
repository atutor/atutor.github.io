/************************************************************************/
/* pnATutor       (/pndocs/readme.txt)                                */
/************************************************************************/

The pnATutor hack for Postnuke is very simple and requires no tables in the DB.

Tested with :
Postnuke 0.726
ATutor 1.3/1.4
Linux/Windows

Location of the ATutor installation is not important.


INSTALLATION
======================
0.  Install ATutor stand alone and verify it is working correct.
1.  Unzip the contents to your /modules directory.
2.  Copy ATutor\*.* to the root of your ATutor directory
3.  Initialise & activate the module
4.  Link the module into a menu block as : {pnATutor}


TIPS
=====
In order to have the application opened in a separate New Window (full screen) do the following :
Create a Core/HTML block with the following contents :
<a href="index.php?module=pnATutor&func=main" target=_blank">ATutor</a>
Make sure that in Admin Panel you have checked the Full Screen option

In order to remove Double Scroll bars and always move to the top of the page :
1.- Put iframe_SSI.html in the root folder of your postnuke site.
2.- Open header.php in the root and insert just above the line saying: 

    themeheader(); 
	this code:
	include ("iframe_SSI.html");
	
	and you will see something like this:

	include ("iframe_SSI.html");
	themeheader();
