<?php
if (!defined("LOADED_AS_MODULE")) {
    die ("You can't access this file directly...");
}
if (!pnLocalReferer()) {
    die ("You can't access this file from and external site...");
}
$guest=pnModGetVar('pnATutor', '_guest');
$home = pnGetBaseURL() ;
$home .= "user.php?op=loginscreen&module=NS-User" ;
if (!pnUserLoggedIn()) {
if ($guest<1){
pnRedirect($home) ;

}
}
$url=pnVarCleanFromInput('url');

if ($url=="") {
die ("Wrong method of calling this module use {} instead of []..");
}
include("header.php");
$filename = realpath ("no_iframe_SSI.html1");
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE'))
{
if (!strpos($_SERVER['HTTP_USER_AGENT'], 'Opera')){
	$filename = realpath ("iframe_SSI.html");
}
}
if (file_exists($filename)){
echo "<iframe id='postwrap-content' name='pnATutor' scrolling='no' class='postwrap-content' src='$url'  frameborder='0' marginheight='0' marginwidth='0' vspace='0' hspace='0'  onload='parent.scrollTo(0,0);' style='overflow:visible; width:100%; display:none'></iframe>";
} else {
echo "<iframe src='$url' align='center' width='100%' height='800px' space=0 vspace=0 marginwidth=0 marginheight=0 frameborder=0 scrolling=auto name='pnATutor' onload='parent.scrollTo(0,0);' ></iframe>";
}include("footer.php");
?>
