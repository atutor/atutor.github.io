# sql file for hello world module

INSERT INTO `language_text` VALUES ('en', '_module','pdf_converter','PDF Converter',NOW(),'');
INSERT INTO `language_text` VALUES ('es-es', '_module','pdf_converter','Convertidor a PDF',NOW(),'');
