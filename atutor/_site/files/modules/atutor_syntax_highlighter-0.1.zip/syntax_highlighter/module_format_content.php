<?php
/*******
 * This file extends the content string manipulation. 
 * It affects the output of course content and news content at course home page.
 * Input parameter: global variable $_input. This variable contains the input 
 * content/news string.
 * Output: $_input. Please make sure to assign the manipulated string back to $_input.
 */

/*******
 * Global input string. DO NOT CHANGE.
 */

global $_input;
include_once 'geshi/geshi.php';

//$match[1] oznacenia kodu - delphi, php, ...
//$match[2] samostatny kod
function replace_code ($match){
  trim(htmlspecialchars_decode($match[2]));
  $geshi = new GeSHi($match[2],$match[1]);
  $geshi->enable_line_numbers(GESHI_NORMAL_LINE_NUMBERS,1);
  $geshi->set_line_style('background: #f0f0f0;', true);
  $geshi->enable_classes; //css styles
  return  '<div class="code">'.$geshi->parse_code().'</div>';
}

function process_content ($content){
  //Replace all the <pre> tags
  $content = preg_replace_callback(
    '/<pre\s+class\s*=\s*["\'](.*?)["\']>(.*?)<\/pre>/s',
    'replace_code',
    $content
  );
  return $content;
}


$_input = process_content($_input);


?>
