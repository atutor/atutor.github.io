# sql file for syntax_highlighter module

INSERT INTO `language_text` VALUES ('en', '_module','syntax_highlighter','Syntax Highlighter',NOW(),'');
INSERT INTO `language_text` VALUES ('sk', '_module','syntax_highlighter','Zvýrazňovač kódu',NOW(),'');
