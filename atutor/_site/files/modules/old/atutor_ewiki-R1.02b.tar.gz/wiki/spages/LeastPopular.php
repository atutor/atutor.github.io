<?php
/*
   being the opposite of MostVisitedPages.
*/

echo ewiki_page_ordered_list("hits", 0, "%nx viewed", $id);

?>