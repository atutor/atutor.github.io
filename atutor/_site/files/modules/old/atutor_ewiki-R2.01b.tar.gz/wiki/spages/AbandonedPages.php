<?php
/*
   pages that were created, but not updated anytime later
*/

echo ewiki_page_ordered_list("version", 0, "", $id);

?>