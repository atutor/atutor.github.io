<!-- BEGIN IMAGE_START -->
			<h3 style="clear:both;">
				{IMAGE_PAGE_TITLE}
			</h3>

	<div style="width: 95%; margin-right: auto; margin-left: auto;">		
	<ul id="navlist">
		<li><a href="{MAIN_URL}" title="{MAIN_TITLE}" class="active"><strong>{MAIN_TITLE}</strong></a></li>
		<li><a href="{MY_PHOTO_URL}" title="{MY_PHOTO_TITLE}">{MY_PHOTO_TITLE}</a></li>
		<li><a href="{MY_COMMENT_URL}" title="{MY_COMMENT_TITLE}">{MY_COMMENT_TITLE}</a></li>
	</ul>
	</div>	
						
	<div class="input-form" style="width:95%">
			<div class="row">
			<!-- BEGIN IMAGE_DISPLAY -->
				<div class="pa_pic_border">
					<a href="{LINK}" title="{IMAGE_TITLE}"><img src="{IMAGE_SRC}" alt="{IMAGE_ALT}" class="pa_img"/></a>
					<p class="pa_p"><a href="{LINK}">{IMAGE_TITLE}</a></p>
				</div>
			<!-- END IMAGE_DISPLAY -->
			</div>
			
			<!-- BEGIN IMAGE_ADD_BUTTON -->
			<div class="row buttons" style="clear:both;">
			<form name="{FORM_NAME}" method="post" action="{ACTION}">
			<input type="submit" name="add" value="{ADD_STRING}"/>
			<input type="hidden" name="mode" value="add"/>
			<input type="hidden" name="choose" value="{CHOOSE_VALUE}"/>
			</form>	
			</div>
			<!-- END IMAGE_ADD_BUTTON -->
		</div>
		
		<div class="row">
		<div id="pa_pagination">
		<ul>
			<!-- BEGIN B_DATA_PART -->
			{B_DATA}
			<!-- END B_DATA_PART -->
		</ul>
		</div>
		</div>
<!-- END IMAGE_START -->
