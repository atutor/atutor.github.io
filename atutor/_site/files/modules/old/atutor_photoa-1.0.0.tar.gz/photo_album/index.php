<?php
/*==============================================================
  Photo Album
 ==============================================================
  Copyright (c) 2006 by Dylan Cheon & Kelvin Wong
  Institute for Assistive Technology / University of Victoria
  http://www.canassist.ca/                                    
                                                               
  This program is free software. You can redistribute it and/or
  modify it under the terms of the GNU General Public License  
  as published by the Free Software Foundation.                
 ==============================================================
 */
// $Id:

/**
 * @desc	This file generates the photo album thumbnail view
 * @author	Dylan Cheon & Kelvin Wong
 * @copyright	2006, Institute for Assistive Technology / University of Victoria 
 * @link	http://www.canassist.ca/                                    
 * @license GNU
 */

define('AT_INCLUDE_PATH', '../../include/');
require_once(AT_INCLUDE_PATH.'vitals.inc.php');
$_custom_css = $_base_path . 'mods/photo_album/module.css'; // use a custom stylesheet
require_once (AT_INCLUDE_PATH.'header.inc.php');
?>

<?php
/* This file is used to display the index page of photo album for everyone */
require_once ('define.php');
require_once ('classes/pa_index.class.php');
require_once ('HTML/Template/ITX.php');
clear_temp_folder();

$index=new Pa_Index();
unset($_SESSION['pa']);

if ($index->isError()!=true){	//if there is no error in index object, display the index page
	$_SESSION['pa']['course_id']=$index->getVariable('course_id');
	
	/* display index page from here */
	$template=new HTML_Template_ITX("./Template");
	$template->loadTemplatefile("index.tpl.php", true, true);
	
	/* display images */
	$template->setCurrentBlock("IMAGE_START");
	$template->setVariable("IMAGE_PAGE_TITLE", _AT('pa_title_index'));
	
	$template->setVariable("MAIN_URL", BASE_PATH.'index.php');
	$template->setVariable("MAIN_TITLE", _AT('pa_tag_course_photo_alt'));
	
	$template->setVariable("MY_PHOTO_URL", BASE_PATH.'my_photo.php');
	$template->setVariable("MY_PHOTO_TITLE", _AT('pa_tag_my_photo_alt'));
	
	$template->setVariable("MY_COMMENT_URL", BASE_PATH.'my_comment.php');
	$template->setVariable("MY_COMMENT_TITLE", _AT('pa_tag_my_comment_alt'));
	
	
	$image_array=$index->getVariable('image_array');
	for ($i=0; $i < count($image_array); $i++) {
		$template->setCurrentBlock("IMAGE_DISPLAY");
		$template->setVariable("LINK", $image_array[$i]['link']);
		$count=get_total_comment_number(STUDENT, $index->getVariable('course_id'), APPROVED, $image_array[$i]['image_id']);
		if ($count >0 ){
			$template->setVariable("IMAGE_TITLE", $image_array[$i]['title']." [".$count."]");
		} else {
			$template->setVariable("IMAGE_TITLE", $image_array[$i]['title']);
		}
		$template->setVariable("IMAGE_SRC", $get_file.$image_array[$i]['location'].urlencode($image_array[$i]['thumb_image_name']));
		$template->setVariable("IMAGE_ALT", $image_array[$i]['alt']);
		$template->parseCurrentBlock("IMAGE_DISPLAY");
	}
	
	if ($index->getVariable('show_modification_buttons')==true){
		$template->setCurrentBlock("IMAGE_ADD_BUTTON");
		$template->setVariable("FORM_NAME", "thumb_form");
		$template->setVariable("ACTION", UPLOAD_ACTION);
		$template->setVariable("ADD_STRING", _AT('pa_button_add_image'));
		$template->setVariable("CHOOSE_VALUE", IMAGE);
		$template->parseCurrentBlock("IMAGE_ADD_BUTTON");
	}

	/* Display page table */
	$page_array=&$index->getVariable('page_array');
	$current=$index->getVariable('current_page');
	if ($index->getVariable('show_page_left_buttons')==true){
		$first_button=_AT('pa_tag_first_page_button');
		$previous_button=_AT('pa_tag_previous_page_button');
		$template->setCurrentBlock("B_DATA_PART");
		$template->setVariable("B_DATA", '<li><a href=\''.BASE_PATH.'index.php?current_page=1\'><img src=\''.FIRST_PAGE_IMAGE.'\' alt=\''.$first_button.'\' width=\'30\' height=\'20\'/></a></li>');
		$template->parseCurrentBlock("B_DATA_PART");
		$template->setCurrentBlock("B_DATA_PART");
		$template->setVariable("B_DATA", '<li><a href=\''.BASE_PATH.'index.php?current_page='.($current-1).'\'><img src=\''.PRE_IMAGE.'\' alt=\''.$previous_button.'\' width=\'30\' height=\'20\'/></a></li>');
		$template->parseCurrentBlock("B_DATA_PART");
	}
	
	for ($i=$page_array['start']; $i<=$page_array['end']; $i++){
		if ($i==$current){
			$template->setCurrentBlock("B_DATA_PART");
			$template->setVariable("B_DATA", '<li class=\'current\'>'.$i.'</li>');
			$template->parseCurrentBlock("B_DATA_PART");
		} else {
			$template->setCurrentBlock("B_DATA_PART");
			$template->setVariable("B_DATA", '<li><a href=\''.BASE_PATH.'index.php?current_page='.$i.'\'>'.$i.'</a></li>');
			$template->parseCurrentBlock("B_DATA_PART");
		}
	}
		
	if ($index->getVariable('show_page_right_buttons')==true){
		$next_button=_AT('pa_tag_next_page_button');
		$last_button=_AT('pa_tag_last_page_button');
		$template->setCurrentBlock("B_DATA_PART");
		$template->setVariable("B_DATA", '<li><a href=\''.BASE_PATH.'index.php?current_page='.($current+1).'\'><img src=\''.NEXT_IMAGE.'\' alt=\''.$next_button.'\' width=\'30\' height=\'20\'/></a></li>');
		$template->parseCurrentBlock("B_DATA_PART");
		$template->setCurrentBlock("B_DATA_PART");
		$template->setVariable("B_DATA", '<li><a href=\''.BASE_PATH.'index.php?current_page='.$page_array['last_page'].'\'><img src=\''.LAST_PAGE_IMAGE.'\' alt=\''.$last_button.'\' width=\'30\' height=\'20\'/></a></li>');
		$template->parseCurrentBlock("B_DATA_PART");
	}
		
	$template->parseCurrentBlock("B_DATA_PART");
	$template->parseCurrentBlock("IMAGE_START");
	$template->parseCurrentBlock();
	$template->show();
} else {
	$msg->addError('pa_obj_pa_index');
	redirect('../../index.php');
}

?>

<?php require_once(AT_INCLUDE_PATH.'footer.inc.php'); ?>
