<?php
/************************************************************************/
/* ATalker															*/
/************************************************************************/
/* Copyright (c) 2002-2005 by Greg Gay                                                                         */
/* Adaptive Technology Resource Centre / University of Toronto			*/
/* http://atutor.ca														*/
/*																		*/
/* This program is free software. You can redistribute it and/or		*/
/* modify it under the terms of the GNU General Public License			*/
/* as published by the Free Software Foundation.						*/
/************************************************************************/
// $Id: 1.0.voices.php 5128 2005-07-12 15:56:36Z greg $

require('../common/body_header.inc.php'); ?>

<h2>1.0 ATalker Voices</h2>

<p>Administrators can use ATalker to create voices for ATutor....</p>

<?php require('../common/body_footer.inc.php'); ?>
