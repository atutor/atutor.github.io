/* N.B. Prima di eseguire lo script, eliminare i record per il linguaggio inglese 'en' e italiano 'it' se gi�
   presenti
*/

/*
Notice: Before launching this script, delete en and it records if necessary

*/


ALTER TABLE AT_languages ADD
	voice_id varchar(4) NULL;
	
insert  into AT_languages values 
('en', 'iso-8859-1', 'ltr', 'en([-_][[:alpha:]]{2})?|english', 'English', 'English', 3, 'en01'), 
('it', 'iso-8859-1', 'ltr', 'it|italian', 'Italian', 'Italian', 3, 'it01');