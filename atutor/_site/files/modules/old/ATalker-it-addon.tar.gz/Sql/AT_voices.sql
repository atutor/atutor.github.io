/*
MySQL Backup
Source Host:           NbMauro
Source Server Version: 4.0.21
Source Database:       atutor
Date:                  2006/01/10 23.16.46
*/

SET FOREIGN_KEY_CHECKS=0;
use atutor;
#----------------------------
# Table structure for AT_voices
#----------------------------
CREATE TABLE `AT_voices` (
  `voice_id` varchar(4) NOT NULL default '',
  `voice_name` varchar(255) NOT NULL default '',
  `voice_volumn` char(2) default NULL,
  `voice_speed` char(3) default NULL,
  PRIMARY KEY  (`voice_id`)
) TYPE=MyISAM;
#----------------------------
# Records for table AT_voices
#----------------------------


insert  into AT_voices values 
('it01', 'voice_lp_mbrola', '1', '1.0'), 
('en01', 'voice_kal_diphone', '1', '1.0'), 
('it02', 'voice_pc_mbrola', '1', '1.0');

