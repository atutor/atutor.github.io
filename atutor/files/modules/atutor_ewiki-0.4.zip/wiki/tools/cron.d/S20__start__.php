<?php 
  /* info-only */
  echo "[$cron]ing script parts in order:\n";
?>