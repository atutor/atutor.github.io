<?php
/*
   This script ensures that we have all required $ewiki_ vars available,
   regardless if we were run in global scopre or not.
*/

global $ewiki_config;
global $ewiki_plugins;
global $_EWIKI;
global $ewiki_id, $ewiki_action, $ewiki_data, $ewiki_links;
global $ewiki_errmsg, $ewiki_t;
global $ewiki_author, $ewiki_auth_user, $ewiki_ring;


?>