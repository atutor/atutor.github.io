<?php
/*
   All default settings. Use `grep define *.*` to get this list.
   Rename this script into "S05myconfig.php" or so and enable what
   you want.
*/

// define("PREPARE_AUTOLINKING", 1);    // for GaGaLink extension

// define("KEPTPAGES", 21);             // in days, influences automatic page deletion
// define("DELETEPAGES", 1);            //
// define("TRASHCAN_ENGAGE", 14);       // in days, how long something must be listed on the special "TrashCan" page before that deletion request is valid
// define("VERHOLES_INTERLEAVE", 10);   // keep every Nth version, off==0
// define("VERHOLES_KEEP_END", 3);      // always keep last num versions
// define("VERHOLES_KEEP_START", 1);    // you SHOULD keep .1 for flat_files!
// define("VERHOLES_NOTOUCH_TIME", 30); // keep versions younger than 30 days

?>