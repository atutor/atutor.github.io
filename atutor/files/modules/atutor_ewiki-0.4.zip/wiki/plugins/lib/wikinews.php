<?php

/*
   prints out a short summary of changed wiki pages
   (an "updated-articles-list")
   
   This code was refactored from page/wikinews.php and returned there for 
   practical reasons.  
   
*/

?>