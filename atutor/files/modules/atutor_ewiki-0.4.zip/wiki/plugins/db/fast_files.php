<?php
#
#  this plugin has been merged with db_flat_files, please go there...
#

define("EWIKI_DB_FAST_FILES", 1);
require(str_replace("/fast_files", "/flat_files", __FILE__));

?>