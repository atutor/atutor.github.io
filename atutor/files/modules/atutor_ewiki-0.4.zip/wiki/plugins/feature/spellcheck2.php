<?php
  require(dirname(__FILE__)."/../edit/spellcheck/ispell.php");
?>