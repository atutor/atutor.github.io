<?php
  require(dirname(__FILE__)."/../edit/spellcheck/pspell.php");
?>