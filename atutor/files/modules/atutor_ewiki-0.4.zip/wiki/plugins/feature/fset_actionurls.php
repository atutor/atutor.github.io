<?php
 /*  will default ewiki to use "?WikiPage&action=view" like URLs  */
 define("EWIKI_ACTION_USE_PARAM", 2);
 define("EWIKI_ACTION_TAKE_ASIS", 0);
?>