<?php

define('AT_INCLUDE_PATH', '../../include/');
/*
require (AT_INCLUDE_PATH.'vitals.inc.php');
authenticate(AT_PRIV_HELLO_WORLD);
require (AT_INCLUDE_PATH.'header.inc.php');

*/
?>
<?php require (AT_INCLUDE_PATH.'index.php'); ?>