<?php
echo 'See the <a href="http://wiki.atutor.ca/plugins/viewsource/viewpagesrc.action?pageId=15400962">Adminstrator Handbook</a>';
?>