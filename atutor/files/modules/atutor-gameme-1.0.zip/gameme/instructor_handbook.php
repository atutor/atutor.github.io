<?php

echo 'See the <a href="http://wiki.atutor.ca/plugins/viewsource/viewpagesrc.action?pageId=15400986">GameMe Instructor Documentation</a>, or see <a href="http://wiki.atutor.ca/plugins/viewsource/viewpagesrc.action?pageId=15761423">Gamifying ATutor Courses</a>.' ;
?>