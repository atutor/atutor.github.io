<h3>
	{PAGE_TITLE}
</h3>
<!-- BEGIN DENY -->
	<div id="deny">
	{REASON}<br>
	Your request is denied.<br>
	Authorization is failed. <br>
	Click <a href="{LINK}">here </a> to go back to beginning.<br>
	If you want to go back to where you were just in, press back button in the web browser.
	</div>
<!-- END DENY -->
	
<!-- BEGIN SUCCESS -->
	<div id="success">
	{MESSAGE}<br>
	You will be redirected to where you started in few seconds.<br>
	If the redirection failes, Click <a href="{LINK}">here </a>to go back where you were.
	</div>
<!-- END SUCCESS -->