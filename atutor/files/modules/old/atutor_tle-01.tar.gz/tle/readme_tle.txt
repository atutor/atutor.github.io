--Readme_TLE Module for ATutor--

This module is used to link The Learning Edge (TLE) learning object repository software into ATutor. TLE must be installed and funtioning before this module will work.

Unzip the TLE module into the modules directroy of your ATutor installation, then in the administrator's module managerment tools in ATutor, choose Install Module, select the TLE module from the list, and follow the prompts.

Once the module has been installed a TLE entry will be added to the Administrator tools under System Preference. 

Click on the TLE link in the System Preferences sub menu, and enter the location of the TLE signon.do file  Something like

http://tle.mysite.com/signon.do 

Then enter the username and shared secret you created in TLE as the shared account that will allow any user on your ATutor system to access the reposiotry.

The primary functionality is found through the TLE link under the Manage Tab in ATutor once the module has been correctly installed. From there as an instructor you can search the TLE content repository, and link content from the repoistory into your courses.

Students can also access the TLE repository through the TLE Student Tool if it has been turned on for a particular course. They can search and view content.

For more information about TLE visit their Web site at:
http://www.thelearningedge.com.au/


