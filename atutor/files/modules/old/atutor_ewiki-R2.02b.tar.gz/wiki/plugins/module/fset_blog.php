<?php 


  require_once("plugins/lib/subpages.php");
  require_once("plugins/module/calendar.php");  
  require_once("plugins/action/calendarlist.php");
  require_once("plugins/page/wikinews.php");
  require_once("plugins/aview/blog.php");

?>