# sql file for EWiki module

INSERT INTO `language_text` VALUES ('en', '_module','wiki','Wiki',NOW(),'');
