#!/bin/sh

wget -c http://erfurtwiki.sourceforge.net/downloads/contrib-add-ons/passdict
