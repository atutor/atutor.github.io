<?php

   //   OBSOLETE - PageIndex is now a core feature (in ewiki.php)

?>