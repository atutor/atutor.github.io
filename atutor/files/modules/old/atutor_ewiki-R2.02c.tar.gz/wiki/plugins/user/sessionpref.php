<?php
/*
   If yoursite already uses PHPs` session extension, then load this
   line to get user/pref support.
*/

$_EWIKI = & $_SESSION["_EWIKI"];   // simple, eh?!

?>