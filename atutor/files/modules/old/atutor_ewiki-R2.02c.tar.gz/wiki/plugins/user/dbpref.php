<?php
/*
   This plugin provides user/pref support by storing/loading the $_EWIKI[]
   vars with the ewiki database. It fires up as soon as $ewiki_author gets
   set to some value.
*/


?>