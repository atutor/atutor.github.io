INSERT INTO `language_text` (
`language_code` ,
`variable` ,
`term` ,
`text` ,
`revised_date` ,
`context`
)
VALUES (
'en', '_module', 'vimeo', 'Vimeo', '0000-00-00 00:00:00', 'Vimeo module name'