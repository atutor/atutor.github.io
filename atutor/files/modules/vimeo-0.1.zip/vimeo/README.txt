About the Vimeo Module:
This module is a simple extension of the output.inc.php file, implementing module_format_output.php to recognize Vimeo videos and embed them into ATutor content via the [media][/media] tags. Embedded vimeo videas may be of the form  [media]http://www.vimeo.com/17065523[/media] or [media]http://vimeo.com/17051816[/media] and make take the height and width options, such as [media|760|480]http://www.vimeo.com/17065523[/media], two integers separated with a pipe.

