<?php
/* each table to be backed up. includes the sql entry and fields */

$dirs = array();
$dirs['my_calendar/'] = AT_CONTENT_DIR . 'my_calendar' . DIRECTORY_SEPARATOR;

$sql = array();
$sql['my_calendar']  = 'SELECT value FROM '.TABLE_PREFIX.'my_calendar WHERE course_id=?';

function my_calendar_convert($row, $course_id, $table_id_map, $version) {
	$new_row = array();
	$new_row[0]  = $course_id;
	$new_row[1]  = $row[0];

	return $new_row;
}

?>