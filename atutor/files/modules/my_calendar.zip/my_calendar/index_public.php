<?php

$_user_location	= 'public';

define('AT_INCLUDE_PATH', '../../include/');
require (AT_INCLUDE_PATH.'vitals.inc.php');
$_custom_css = $_base_path . 'mods/my_calendar/module.css'; // use a custom stylesheet
require (AT_INCLUDE_PATH.'header.inc.php');
?>
<link rel='stylesheet' type='text/css' href='fullcalendar/fullcalendar/fullcalendar.css' />
<link rel='stylesheet' type='text/css' href='fullcalendar/fullcalendar/fullcalendar.print.css' media='print' />
<script type='text/javascript' src='fullcalendar/jquery/jquery-1.7.1.min.js'></script>
<script type='text/javascript' src='fullcalendar/jquery/jquery-ui-1.8.17.custom.min.js'></script>
<script type='text/javascript' src='fullcalendar/fullcalendar/fullcalendar.min.js'></script>
<script type='text/javascript' src='fullcalendar/fullcalendar/gcal.js'></script>

<?php

$command = "SELECT * FROM ".TABLE_PREFIX."my_calendar_urls ";
$result = mysql_query($command, $db);

while ($row = mysql_fetch_assoc($result)) {
	
    $url =  $row['calendar_array'];
    $urls[] = $url;
}
/*print_r($urls);
echo implode(",", $urls);*/?>

<div /*id="helloworld"*/ style="width:auto;">
	<p style="padding-bottom:10px;">This is the public page for the mycalendar module. Here is where I can write stuff like  :)
	<?php echo "Hi-".$_SESSION['valid_user']."-".$_SESSION['login'].$_SESSION['member_id'];
	
	$command = "SELECT status FROM ".TABLE_PREFIX."members WHERE member_id = '{$_SESSION['member_id']}' AND status='3'";
	$result = mysql_query($command, $db);
	if(mysql_num_rows($result) > 0){
	echo "<br/><br/>You are a teacher and we can special stuff here.";
	}else{
	echo "<br/><br/>You are a student. Special student stuff goes here."; ?>				
</p>
<style type='text/css'>

	    #calendar {
		width: 900px;
		margin: 0 auto;
		color:red;
		}
		
		h2{color:#2f2f2f;}
		color:red;
		
		.fc-event-title {
    float: left;
    padding: 0 1px;
    text-align: left;
}

</style>

	<div id="container" style="background-color:white;border:none;" >
                    
<div id="main" style="background:white;">
   	

		<!--calendar stuff -->
		
<div style="display:block; width:900px; margin: 0 auto; margin-top:10px;">
<div style="float:right; margin-bottom:10px;">
<form style="display:none;"" action="<?php echo $_SERVER[PHP_SELF]; ?>" method="post">
<input type="submit" name="add_event" value="Add Event"/>
</form>
<p style="display:none">Add Event | Edit Event | Delete Event</p></div>
</div>

<div style="clear:both;"></div>


<?php if($_POST['add_event']){
$year = date("Y"); 
$year2= $year + 1;
$mymonth = date("m"); 
$day = date("d");?>
<div style="background-color:grey; width:900px; margin:0 auto;padding-top:20px;padding-bottom:10px; border-radius:15px;">
<form action="<?php echo $_SERVER[PHP_SELF]; ?>" method="post">
<div style="float:left;margin-left:10px;">Title: <input style="margin:0 auto; text-align:left;" type="text" name="event_title" value=""/>
<select name ="year">
<?php echo '<option selected="selected">'.$year.'</option>';
echo '<option>'.$year2.'</option>';

echo '</select>';
?>

<select name ="month">
<?php 
$month = array($month);
echo '<option selected="selected">'.$mymonth.'</option>';
$months = array('01','02','03','04','05','06','07','08','09','10','11','12');
$months = array_diff($months,$month);

foreach($months as $month_opt){
echo '<option>'.$month_opt.'</option>';
}
echo '</select>';

?>

<select name="day">
<?php echo '<option selected="selected">'.$day.'</option>';
for($i=1; $i<32; $i++) {
echo '<option>'.$i.'</option>';
}

echo '</select>';
?>
&nbsp Hour: <select name="hour">
<?php 
$hours = array('00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23');

foreach($hours as $hour){
echo '<option>'.$hour.'</option>';
}

echo '</select>';

?>
&nbsp Minutes: <select name="minutes">
<?php 
$minutes = array('00','15','30','45');

foreach($minutes as $minute){
echo '<option>'.$minute.'</option>';
}

echo '</select>';
echo'</div>';
?><br/><br/>
<div style="float:left;margin-left:10px;margin-bottom:5px;">Notes:</div>
<textarea name="notes" style="width:880px; margin:0 auto; margin-left:7px;"></textarea><br/>

<?php
echo '<input style="margin-top:10px; margin-left:7px;" type="submit" name="adding" value="Add the Event"/></form></div><br/><br/>';
} 

if($_POST['adding']) {
$year = $_POST['year'];
$month = $_POST['month'];
$day= $_POST['day'];
$hour= $_POST['hour'];
$minutes= $_POST['minutes'];
$title = mysql_real_escape_string($_POST['event_title']);
$notes = mysql_real_escape_string($_POST['notes']);
$fulldate = $year."-".$month."-".$day." ".$hour.":".$minutes;

$command = "INSERT INTO ".TABLE_PREFIX."my_calendar VALUES('','0', '$title', '$notes', '$fulldate','') ";
$result = mysql_query($command, $db);
if($result) {
echo "Successful Insert!";
}
}
?>
<div style="clear:both;"></div>
<div id="calendar"></div>

</div></div>

<div style="clear:both;"></div>
	

	
<?php	
	}?>
</div>
				<script>
$(document).ready(function() {

    $('#calendar').fullCalendar({
	
	    header: {
			left: 'prev,next',
			center: 'title',
			right: 'month,basicWeek,basicDay'
		},
		editable: false,
	
        eventSources: [		
		/* 'https://www.google.com/calendar/feeds/kelchuk68%40gmail.com/public/basic',
		'events.php',
		'mods/my_calendar/events.php'*/
		<?php echo implode(",", $urls); ?>
		]		
		  });
});	
</script>
<?php require (AT_INCLUDE_PATH.'footer.inc.php'); ?>