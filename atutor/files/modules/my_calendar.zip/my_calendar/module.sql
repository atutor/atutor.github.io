# custom tables

CREATE TABLE `my_calendar` (
  `id` int(11) NOT NULL auto_increment,
  `member_id` int(11) NOT NULL,
  `title` varchar(55) NOT NULL,
  `notes` text NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=112 ;


CREATE TABLE `my_calendar_urls` (
  `id` int(11) NOT NULL auto_increment,
  `member_id` int(11) NOT NULL,
  `calendar_array` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;


INSERT INTO `my_calendar_urls` (`id`, `member_id`, `calendar_array`) VALUES
(1, 0, '''mods/my_calendar/events.php'''),
(3, 0, '''https://www.google.com/calendar/feeds/kelchuk68%40gmail.com/public/basic''');

INSERT INTO `language_text` VALUES ('en', '_module','my_calendar','My Calendar',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','my_calendar_tool','My calendar Tool',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','my_calendar_text','Coding Area.',NOW(),'');

