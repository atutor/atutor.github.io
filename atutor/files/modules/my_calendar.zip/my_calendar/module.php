<?php
/*******
 * doesn't allow this file to be loaded with a browser.
 */
if (!defined('AT_INCLUDE_PATH')) { exit; }

/******
 * this file must only be included within a Module obj
 */
if (!isset($this) || (isset($this) && (strtolower(get_class($this)) != 'module'))) { exit(__FILE__ . ' is not a Module'); }

/*******
 * assign the instructor and admin privileges to the constants.
 */
define('AT_PRIV_MY_CALENDAR',       $this->getPrivilege());
define('AT_ADMIN_PRIV_MY_CALENDAR', $this->getAdminPrivilege());

/*******
 * create a side menu box/stack.
 */
$this->_stacks['my_calendar'] = array('title_var'=>'my_calendar', 'file'=>'mods/my_calendar/side_menu.inc.php');
// ** possible alternative: **
// $this->addStack('my_calendar', array('title_var' => 'my_calendar', 'file' => './side_menu.inc.php');

/*******
 * create optional sublinks for module "detail view" on course home page
 * when this line is uncommented, "mods/my_calendar/sublinks.php" need to be created to return an array of content to be displayed
 */
//$this->_list['my_calendar'] = array('title_var'=>'my_calendar','file'=>'mods/my_calendar/sublinks.php');

// Uncomment for tiny list bullet icon for module sublinks "icon view" on course home page
//$this->_pages['mods/my_calendar/index.php']['icon']      = 'mods/my_calendar/my_calendar_sm.jpg';

// Uncomment for big icon for module sublinks "detail view" on course home page
//$this->_pages['mods/my_calendar/index.php']['img']      = 'mods/my_calendar/my_calendar.jpg';

// ** possible alternative: **
// the text to display on module "detail view" when sublinks are not available
$this->_pages['mods/my_calendar/index.php']['text']      = _AT('my_calendar_text');

/*******
 * if this module is to be made available to students on the Home or Main Navigation.
 */
$_group_tool = $_student_tool = 'mods/my_calendar/index.php';

/*******
 * add the admin pages when needed.
 */
if (admin_authenticate(AT_ADMIN_PRIV_MY_CALENDAR, TRUE) || admin_authenticate(AT_ADMIN_PRIV_ADMIN, TRUE)) {
	$this->_pages[AT_NAV_ADMIN] = array('mods/my_calendar/index_admin.php');
	$this->_pages['mods/my_calendar/index_admin.php']['title_var'] = 'my_calendar';
	$this->_pages['mods/my_calendar/index_admin.php']['parent']    = AT_NAV_ADMIN;
}

/*******
 * instructor Manage section:
 */
$this->_pages['mods/my_calendar/index_instructor.php']['title_var'] = 'my_calendar';
$this->_pages['mods/my_calendar/index_instructor.php']['parent']   = 'tools/index.php';
// ** possible alternative: **
// $this->pages['./index_instructor.php']['title_var'] = 'my_calendar';
// $this->pages['./index_instructor.php']['parent']    = 'tools/index.php';

/*******
 * student page.
 */
$this->_pages['mods/my_calendar/index.php']['title_var'] = 'my_calendar';
$this->_pages['mods/my_calendar/index.php']['img']       = 'mods/my_calendar/my_calendar.jpg';

/* public pages */
$this->_pages[AT_NAV_PUBLIC] = array('mods/my_calendar/index_public.php');
$this->_pages['mods/my_calendar/index_public.php']['title_var'] = 'my_calendar';
$this->_pages['mods/my_calendar/index_public.php']['parent'] = AT_NAV_PUBLIC;

/* my start page pages */
$this->_pages[AT_NAV_START]  = array('mods/my_calendar/index_mystart.php');
$this->_pages['mods/my_calendar/index_mystart.php']['title_var'] = 'my_calendar';
$this->_pages['mods/my_calendar/index_mystart.php']['parent'] = AT_NAV_START;

/* my edit calendar pages */
//$this->_pages[AT_NAV_START]  = array('mods/my_calendar/edit_calendar.php');
$this->_pages['mods/my_calendar/edit_calendar.php']['title_var'] = 'my_calendar'; // need this to use header.inc.php file
//$this->_pages['mods/my_calendar/edit_calendar.php']['parent'] = AT_NAV_START;

/*******
 * Use the following array to define a tool to be added to the Content Editor's icon toolbar. 
 * id = a unique identifier to be referenced by javascript or css, prefix with the module name
 * class = reference to a css class in the module.css or the primary theme styles.css to style the tool icon etc
 * src = the src attribute for an HTML img element, referring to the icon to be embedded in the Content Editor toolbar
 * title = reference to a language token rendered as an HTML img title attribute
 * alt = reference to a language token rendered as an HTML img alt attribute
 * text = reference to a language token rendered as the text of a link that appears below the tool icon
 * js = reference to the script that provides the tool's functionality
 */

$this->_content_tools[] = array("id"=>"mycalendar_tool", 
                                "class"=>"fl-col clickable", 
                                "src"=>AT_BASE_HREF."mods/my_calendar/my_calendar.jpg",
                                "title"=>_AT('my_calendar_tool'),
                                "alt"=>_AT('my_calendar_tool'),
                                "text"=>_AT('my_calendar'), 
                                "js"=>AT_BASE_HREF."mods/my_calendar/content_tool_action.js");

/*******
 * Register the entry of the callback class. Make sure the class name is properly namespaced, 
 * for instance, prefixed with the module name, to enforce its uniqueness.
 * This class must be defined in "ModuleCallbacks.class.php".
 * This class is an API that contains the static methods to act on core functions.
 */
$this->_callbacks['my_calendar'] = 'MyCalendarCallbacks';

function my_calendar_get_group_url($group_id) {
	return 'mods/my_calendar/index.php';
}
?>