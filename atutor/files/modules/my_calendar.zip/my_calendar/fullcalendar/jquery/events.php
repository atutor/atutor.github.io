<?php 
session_start();
date_default_timezone_set('America/Los_Angeles');
include ("connect.inc");
$db=public_db_connect();
	$year = date('Y');
	$month = date('m');

$command = "SELECT * FROM calendar WHERE id > 0";
$result = mysql_query($command, $db);

while ($row = mysql_fetch_assoc($result)) {
	//echo "hi";
    //$start = date("D, j M Y G:i:s T", strtotime($row['start']));
    //$end = date("D, j M Y G:i:s T", strtotime($row['end_time'])); 
	$start = date("Y-m-d", strtotime($row[start]));
	//$start = "$year-$month-20";
    $eventsArray['id'] =  $row['id'];
    $eventsArray['title'] = $row['title'];  
	$eventsArray['title'] = date("Ga", strtotime($row['start']))." ".substr($row['title'], 0, 15)."..."; 
    $eventsArray['start'] = $start;
	$eventsArray['url'] = "edit_calendar.php?calendarid=".$row['id'];
    // $eventsArray['end'] = $end;
    // $eventsArray['allDay'] = false;
    $events[] = $eventsArray;
}

echo json_encode($events);


	/*$year = date('Y');
	$month = date('m');

	echo json_encode(array(
	
		array(
			'id' => 1,
			'title' => "Event#1",
			'start' => "$year-$month-21",
			'url' => "http://google.com/"
		),
		
		array(
			'id' => 2,
			'title' => "Event#2",
			'start' => "$year-$month-21",
			'end' => "$year-$month-22",
			'url' => "http://google.com/"
		)
	
	));
*/
?>
