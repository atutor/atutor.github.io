<?php 
session_start();
date_default_timezone_set('America/Los_Angeles');
include ("../../include/config.inc.php");
include ("connect.inc");
$db2=public_db_connect();
	$year = date('Y');
	$month = date('m');

$command = "SELECT * FROM ".TABLE_PREFIX."my_calendar WHERE id >'0' ";
$result = mysql_query($command, $db2);

while ($row = mysql_fetch_assoc($result)) {
	//echo "hi";
    //$start = date("D, j M Y G:i:s T", strtotime($row['start']));
    //$end = date("D, j M Y G:i:s T", strtotime($row['end_time'])); 
	$start = date("Y-m-d", strtotime($row[start]));
	//$start = "$year-$month-20";
    $myid =  $row['id'];
	$eventsArray['id'] =  (int)trim($myid);	
    //$eventsArray['title'] = $row['title'];  
	$title = date("Ga", strtotime($row['start']))." ".$row['title']; 
	//$title = $row['title']; 
	//echo $title;
	$eventsArray['title'] = $title; 
    $eventsArray['start'] = $start;
	$eventsArray['end'] = $start;
    $eventsArray['url'] = "mods/my_calendar/edit_calendar.php?calendarid=".$row['id'];
    // $eventsArray['end'] = $end;
    // $eventsArray['allDay'] = false;
    $events[] = $eventsArray;
}
//print_r($events);
//$events = array_unique($events);

//echo "<br/><br/>";
echo json_encode($events);


	/*$year = date('Y');
	$month = date('m');

	echo json_encode(array(
	
		array(
			'id' => 1,
			'title' => "Event#1",
			'start' => "$year-$month-21",
			'url' => "http://google.com/"
		),
		
		array(
			'id' => 2,
			'title' => "Event2",
			'start' => "$year-$month-21",
			'end' => "$year-$month-22",
			'url' => "google.com"
		)
	
	));*/
	
	/*$test = array(array(
			'id' => 1,
			'title' => "Event#1",
			'start' => "$year-$month-21",
			'url' => "http://google.com/"
		),
		
		array(
			'id' => 2,
			'title' => "Event2",
			'start' => "$year-$month-21",
			'end' => "$year-$month-22",
			'url' => "google.com"
		)
	
	);*/
	
	//print_r($test);

?>
