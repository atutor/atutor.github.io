<?php
$_user_location	= 'users';
define('AT_INCLUDE_PATH', '../../include/');
require (AT_INCLUDE_PATH.'vitals.inc.php');
authenticate(AT_PRIV_MY_CALENDAR);
//if (get_instructor_status() === FALSE) {
require (AT_INCLUDE_PATH.'header.inc.php');
//}
?>

Hello Instructor!! :)
<?php echo "Hi-".$_SESSION['valid_user']."-".$_SESSION['login'].$_SESSION['member_id'];?>

<?php require (AT_INCLUDE_PATH.'footer.inc.php'); ?>