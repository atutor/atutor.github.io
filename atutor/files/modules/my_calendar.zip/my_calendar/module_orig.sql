# sql file for hello world module

CREATE TABLE `my_calendar` (
   `my_calendar_id` mediumint(8) unsigned NOT NULL,
   `course_id` mediumint(8) unsigned NOT NULL,
   `value` VARCHAR( 30 ) NOT NULL ,
   PRIMARY KEY ( `my_calendar_id` )
);

INSERT INTO `language_text` VALUES ('en', '_module','my_calendar','My Coding calendar',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','my_calendar_tool','My calendar Tool',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','my_calendar_text','Coding Area.',NOW(),'');