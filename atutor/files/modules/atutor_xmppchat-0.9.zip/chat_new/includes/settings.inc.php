
        <div id="settings">
        It is highly recommended that you use the registered on <a href="https://www.talkr.im/">talkr.im</a> server account only within the ATutor chat client to avoid loss of data or other undesirable consequences.<br/>
		
		Please see <a href="<?php echo $_base_path; ?>mods/chat_new/ATutor_XMPP_Chat_READ_ME.pdf" target="_blank">the helping document</a> for more details.<br/><br/>
        	
        	
        	<!--<div class="settings_category"><strong>Chat</strong></div>
        		<input type="radio" name="settings_chat" value="on" checked/>On<input type="radio" name="settings_chat" value="off" />Off
        		
        		
        	<div class="settings_category"><strong>History</strong>        		
        		<img class="settings_details" id="settings_history_opener" src="<?php echo $_base_path; ?>/images/help.png" alt="details"/>
        		<div id="settings_history_dialog" title="History">
					<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
				</div>        		
        	</div>        	
        	<input type="radio" name="settings_history" value="save" checked/>Save<input type="radio" name="settings_history" value="nosave" />Never save
        		
        		
        	<div class="settings_category"><strong>Sound</strong></div>
        	<input type="radio" name="settings_sound" value="on" checked/>On<input type="radio" name="settings_sound" value="off" />Off
        		
        		
        	<div class="settings_category"><strong>Notifications</strong></div>
        	<input type="radio" name="settings_nitifications" value="page" checked/>This page<input type="radio" name="settings_nitifications" value="everywhere" />Everywhere
        	
        	
        	<div class="settings_category">
        		<strong>Everyone can see me except</strong>
        		
        		<img class="settings_details" id="settings_blacklist_opener" src="<?php echo $_base_path; ?>/images/help.png" alt="details"/>
        		<div id="settings_blacklist_dialog" title="Blacklist">
					<p>This is the default dialog which is useful for displaying information. The dialog window can be moved, resized and closed with the 'x' icon.</p>
				</div>				
        	</div>
        	
        	
        		<table id="settings_table"><tr>
        			<td><textarea id="settings_blacklist" name="blacklist"></textarea></td>
        			<td><input id="settings_blacklist_upd" type="button" label="submit" value="Upate"/></td>
        		</tr></table>
        	
        	<br/><br/>	
        	<input id="settings_save" type="button" label="submit" value="Save changes"/>-->
        	
        </div>
