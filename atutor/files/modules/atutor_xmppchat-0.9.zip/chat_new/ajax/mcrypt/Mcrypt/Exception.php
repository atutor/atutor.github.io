<?php
class Anti_Mcrypt_Exception extends Anti_Exception {}