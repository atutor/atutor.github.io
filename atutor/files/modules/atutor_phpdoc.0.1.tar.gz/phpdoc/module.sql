# sql file for PHPDoc module


INSERT INTO `language_text` VALUES ('en', '_module','phpdoc','PHPDoc',NOW(),'');
