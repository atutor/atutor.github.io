# sql file for hello world module


INSERT INTO `language_text` VALUES ('en', '_module','utf8conv','UTF8 Conversion',NOW(),'');
