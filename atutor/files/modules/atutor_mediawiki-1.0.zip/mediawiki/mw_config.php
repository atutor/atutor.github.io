<?php
// MediaWiki database access information.
// Set the values below to those needed to access your MediaWiki database
// Mediawiki needs to be installed in the same server as ATutor

define('MW_DB_USER',	'root');           # enter your mysql database user name
define('MW_DB_PWD',	'4rft6yhu');           # enter your mysql database password
define('MW_DB_NAME',	'wikidb');         #default "wikidb"
define('MW_DB_PREFIX',	'mw_');            #default "mw_"
define('MW_DB_HOST',	'localhost');      #default "localhost"
define('MW_DB_PORT',	'3600');           #default "3600"

?>