CREATE TABLE `DS_agreed_logins` (
   `login` varchar(30) NOT NULL,
   PRIMARY KEY ( `login` )
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


INSERT INTO `language_text` VALUES ('en', '_module','disclaimer','Legal Disclaimer',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','enable_terms_and_conditions','Enable Legal Disclaimer',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','tac_link','Where to redirect if users do not agree to the legal disclaimer',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','tac_attention','Before using this Online Learning System, please indicate that you agree with the following terms by clicking on the \"Yes, I Agree\" button located below.',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','i_agree','Yes, I Agree',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','i_do_not_agree','No, I do not Agree',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_msgs','AT_FEEDBACK_TAC_SAVED','Legal Disclaimer is saved successfully.',NOW(),'');