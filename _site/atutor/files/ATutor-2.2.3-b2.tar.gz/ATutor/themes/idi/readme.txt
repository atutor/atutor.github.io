
Theme:		Plone-like
Date:		March 2005


Installing:	See section "Installing a New Theme" in the themes_readme.txt file located in docs/themes/.

Licence:	Falls under the GPL agreement.  See http://www.gnu.org/copyleft/gpl.html.
	