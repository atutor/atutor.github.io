<?php if (!defined('AT_INCLUDE_PATH')) { exit; } ?>

<br />
<h2 class="box"><?php echo $this->title; ?><input class="fl-force-right" src="" alt="" title="" type="image" /></h2>
<div class="box">
		<?php echo $this->dropdown_contents; ?>
</div>