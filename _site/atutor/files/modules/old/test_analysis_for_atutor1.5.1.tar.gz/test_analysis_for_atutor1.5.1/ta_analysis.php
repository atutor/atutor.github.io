<?php
/****************************************************************/
/* Test Analysis Module for ATutor 1.4.3 														*/
/****************************************************************/
/* Copyright (c) 2005 by Peera Patprasert        */
/* Computer Center,  Srinakhrinwirot University  */
/* Bangkok, Thailand.
/* http://course.swu.ac.th/												*/
/*                                                              */
/*                                                              */
/* This program is free software. You can redistribute it and/or*/
/* modify it under the terms of the GNU General Public License  */
/* as published by the Free Software Foundation.				*/
/****************************************************************/

/*** Information for PHP_Doc ***
   * @prog_desc_th	������������������ͺ��������Ţͧ ATutor ��觨���������Ẻ��駩�Ѻ������� Item.
   * @prog_desc	Test Analysis module showing analyzed summary and item analysis.
   * @throws		not until PHP 5
   * @todo			installation as plug-in
   * @requirement   ATutor version 1.4.3, PHP version 4.3.0
   * @since			Feb 3, 2005
   * @author		Asst.Prof.Dr.Sunee Raksakeitisak, 
							Mr.Peera Patprasert, 
							Ms.Waraporn Viyanon, 
							Ms.Sasivimo Sukaphat
   */
/****************************************************************/

$page = 'tests';
define('AT_INCLUDE_PATH', '../../include/');
require(AT_INCLUDE_PATH.'vitals.inc.php');

if (!authenticate(AT_PRIV_TEST_MARK, true)) {
	$msg->addError('ACCESS_DENIED');
	header('Location: index.php');
	exit;
}

//$tid = intval($_REQUEST['tid']);
	$tid = intval($_GET['tid']);
	if ($tid == 0){
		$tid = intval($_POST['tid']);
	}

$_pages['tools/tests/ta_analysis.php']['title_var']  = 'ta_analyse_this_test';
$_pages['tools/tests/ta_analysis.php']['parent']  = 'tools/tests/index.php';
//$_pages['tools/tests/ta_analysis.php']['children'] = array('tools/tests/results_all.php?tid='.$tid);

//$_pages['tools/tests/results_all.php?tid='.$tid]['title_var']  = 'mark_statistics';
//$_pages['tools/tests/results_all.php?tid='.$tid]['parent'] = 'tools/tests/results_all_quest.php';

//require(AT_INCLUDE_PATH.'header.inc.php');
//	require(AT_INCLUDE_PATH.'vitals.inc.php');
//	$_section[0][0] = _AT('tools');
//	$_section[0][1] = 'tools/index.php';
//	$_section[1][0] = _AT('test_manager');
//	$_section[1][1] = 'tools/tests/index.php';
//	$_section[2][0] = _AT('results');

//	authenticate(AT_PRIV_TEST_MARK);



require(AT_INCLUDE_PATH.'header.inc.php');


$sql	= "SELECT TQ.*, TQA.* FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid ORDER BY TQA.ordering, TQA.question_id";
$result	= mysql_query($sql, $db);
$questions = array();
while ($row = mysql_fetch_array($result)) {
	$row['score']	= 0;
	$questions[]	= $row;
	$q_sql .= $row['question_id'].',';
}
$q_sql = substr($q_sql, 0, -1);
$num_questions = count($questions);

//check if survey
$sql	= "SELECT out_of, title, randomize_order FROM ".TABLE_PREFIX."tests WHERE test_id=$tid";
$result = mysql_query($sql, $db);
$row = mysql_fetch_assoc($result);
$tt = $row['title'];
$random = $row['randomize_order'];

echo '<h3>'.$row['title'].'</h3><br />';




/*
echo '<h2>';
	if ($_SESSION['prefs'][PREF_CONTENT_ICONS] != 2) {
		echo '<a href="tools/index.php" class="hide"><img src="images/icons/default/square-large-tools.gif"  class="menuimage" border="0" vspace="2" width="42" height="40" alt="" /></a>';
	}
	if ($_SESSION['prefs'][PREF_CONTENT_ICONS] != 1) {
		echo ' <a href="tools/index.php" class="hide">'._AT('tools').'</a>';
	}
echo '</h2>';

echo '<h3>';
	if ($_SESSION['prefs'][PREF_CONTENT_ICONS] != 2) {
		echo '&nbsp;<img src="images/icons/default/test-manager-large.gif"  class="menuimageh3" width="42" height="38" alt="" /> ';
	}
	if ($_SESSION['prefs'][PREF_CONTENT_ICONS] != 1) {
		echo '<a href="tools/tests/index.php">'._AT('test_manager').'</a>';
	}
echo '</h3>';
*/
/*
	//check if survey
	$sql	= "SELECT out_of, title FROM ".TABLE_PREFIX."tests WHERE test_id=$tid";
	$result = mysql_query($sql, $db);
	$row = mysql_fetch_array($result);
	$tt = $row['title'];




	echo '<h4>'._AT('results_for', AT_print($tt, 'tests.title')).'</h4>';
	echo '<p><br /><a href="tools/tests/results_all_quest.php?tid='.$tid.'">' . _AT('question_statistics').'</a> | <a href="tools/tests/results_all.php?tid='.$tid.'">' . _AT('mark_statistics') . '</a>';
	echo '  | <strong>'. _AT('ta_analyse_this_test').'</strong>';
	echo '</p>';
*/
/******************************************************************/
/******************* Begining of calculate part *************************/

	$sql	= "SELECT R.*, M.login FROM ".TABLE_PREFIX."tests_results R, ".TABLE_PREFIX."members M WHERE R.test_id=$tid AND R.final_score<>'' AND R.member_id=M.member_id ORDER BY M.login, R.date_taken";
	$result = mysql_query($sql, $db);
	if ($row = mysql_fetch_array($result)) {  //if data exist.

		// Sample Size 
		$sql	= "SELECT COUNT(member_id) FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
		$result	= mysql_query($sql, $db);
		$Sample_Size=mysql_result($result,0,0);

		//Number of questions
		$sql	= "SELECT  COUNT(TQA.question_id) FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid";


		$result	= mysql_query($sql, $db);
		$Total_Item=mysql_result($result,0,0);
		
		//Exam Total Score
		$sql= "SELECT SUM(TQA.weight) FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid";
		$result = mysql_query($sql,$db);
		$Total_Score = mysql_result($result,0,0);


		//************************************
		//Begining: Number of Choices
		$Total_Choice=0;
		$sql= "SELECT TQ.*, TQA.* FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid";
		$result	= mysql_query($sql, $db);
		$Total_Choice=0;
		while ($chkchoice = mysql_fetch_array($result)) {
			if ($chkchoice['choice_9']!="" AND $Total_Choice<10){
				$Total_Choice=10;
			}else if ($chkchoice['choice_8']!="" AND $Total_Choice<9){
				$Total_Choice=9;
			}else if ($chkchoice['choice_7']!="" AND $Total_Choice<8){
				$Total_Choice=8;
			}else if ($chkchoice['choice_6']!="" AND $Total_Choice<7){
				$Total_Choice=7;
			}else if ($chkchoice['choice_5']!="" AND $Total_Choice<6){
				$Total_Choice=6;
			}else if ($chkchoice['choice_4']!="" AND $Total_Choice<5){
				$Total_Choice=5;
			}else if ($chkchoice['choice_3']!="" AND $Total_Choice<4){
				$Total_Choice=4;
			}else if ($chkchoice['choice_2']!="" AND $Total_Choice<3){
				$Total_Choice=3;
			}else if ($chkchoice['choice_1']!="" AND $Total_Choice<2){
				$Total_Choice=2;
			}else if ($chkchoice['choice_0']!="" AND $Total_Choice<1){
				$Total_Choice=1;
			}
		}
		//Ending: Number of Choices
		//************************************

		
		//Maximum score
		$sql	= "SELECT MAX(final_score + 0) FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
		$result	= mysql_query($sql, $db);
		$Max=mysql_result($result,0,0);

		//Minimum score
		$sql	= "SELECT MIN(final_score + 0) FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
		$result	= mysql_query($sql, $db);
		$Min=mysql_result($result,0,0);
		if ($Min == ""){
			$Min = 0;
		}

		//Average score
		$sql	= "SELECT SUM(final_score) FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
		$result	= mysql_query($sql, $db);
		$Mean=mysql_result($result,0,0);
		if ($Sample_Size!=0) {
			$Mean = number_format($Mean / $Sample_Size,3);
		} else {
			$Mean = 0;
		};

		//Mean score
		$sql	= "SELECT final_score  FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ORDER BY (final_score+0)";
		$result	= mysql_query($sql, $db);
		$chkrows=mysql_num_rows($result);


	
		$i=(int)(mysql_num_rows($result)/2);

		if ($chkrows%2==0){
			$num1=mysql_result($result,($i-1),0);
			$num2=mysql_result($result,($i),0);
			$Medium = number_format(($num1+$num2)/2,3);
		}else{
			$Medium = mysql_result($result,($i),0);
		}


/*
		if ($chkrows%2==0){
			$i=(int)(mysql_num_rows($result)/2);
			$num1=mysql_result($result,($i-1),0);
			$num2=mysql_result($result,($i),0);
			$Medium = number_format(($num1+$num2)/2,3);
		}else{
			$Medium = mysql_result($result,($i-1),0);
		}
*/

		//Standard Deviation
		$SD=0;
		for ($cnt=0;$cnt<$Sample_Size;$cnt++){
			$SD = $SD + ((mysql_result($result,$cnt,0)-$Mean)*(mysql_result($result,$cnt,0)-$Mean));
		}
		$variance_y = $SD/($Sample_Size-1);
		$SD=number_format(sqrt($variance_y),3);


		//************************************
		//Begining: Item analysis

		$AD=0;$ADC=0;$sum_variance=0;

		$sql= "SELECT TQ.*, TQA.* FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid ORDER BY TQA.ordering, TQA.question_id";
		$result = mysql_query($sql,$db);
		$i=1;
		while ($question = mysql_fetch_array($result)){   
			$sql= "SELECT * FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
			$result1 = mysql_query($sql,$db);

			//************************************
			//Begining: each choice statistics  (P value)
			$P_Value[$i]=0;$R_Value[$i]=0;$sum_xy=0;$sum_xx=0;$sum_yy=0;$sum_corrected_xy=0;$sum_corrected_yy=0;
			for($k = 1; $k<= $Total_Choice; $k++) {$Q[$i][$k]=0;}
			while ($results =mysql_fetch_array($result1)){
				$sql= "SELECT * FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id=".$question['question_id']."";
				$result2 = mysql_query($sql,$db);
				$answer = mysql_fetch_array($result2);
				$P_Value[$i] = $P_Value[$i]+$answer['score'];
				$Real_P_Value[$i] =number_format( ($P_Value[$i] / $Sample_Size)/$question['weight'],2);
				$sum_xy=$sum_xy+($answer['score']*$results['final_score']);
				$sum_xx=$sum_xx+($answer['score']*$answer['score']);
				$sum_yy=$sum_yy+($results['final_score']*$results['final_score']);
				$sum_corrected_yy=$sum_corrected_yy+(($results['final_score']-$answer['score'])*($results['final_score']-$answer['score']));
				$sum_corrected_xy=$sum_corrected_xy+($answer['score']*($results['final_score']-$answer['score']));
				for($k = 1; $k<= $Total_Choice; $k++) {
					if ($question['type']==1){
						$sql= "SELECT COUNT(answer) FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id=".$question['question_id']." AND answer=".($k-1)."";
						$result3 = mysql_query($sql,$db);
						$cnt=mysql_result($result3,0,0);
						if ($cnt<>0){
							$Q[$i][$k]=$Q[$i][$k]+$cnt;}
					}else if ($question['type']==2){
						$sql= "SELECT COUNT(answer) FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id=".$question['question_id']." AND answer=".($k)."";
						$result3 = mysql_query($sql,$db);
						$cnt=mysql_result($result3,0,0);
						if ($cnt<>0){
							$Q[$i][$k]=$Q[$i][$k]+$cnt;}
						if ($k==2){
							$k=$Total_Choice;}
					}else if ($question['type']==4){
						$sql= "SELECT COUNT(answer) FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id=".$question['question_id']." AND answer=".($k-1)."";
						$result3 = mysql_query($sql,$db);
						$cnt=mysql_result($result3,0,0);
						if ($cnt<>0){
							$Q[$i][$k]=$Q[$i][$k]+$cnt;}
					} //end if
				} // end for
			} // end while

			//Ending: each choice statistics
			//************************************


			$sum_x = $P_Value[$i];
			$P_Value[$i] = number_format($P_Value[$i] / $Sample_Size,2);
			$AD = $AD + $Real_P_Value[$i];
			$sum_corrected_y=0;
			
			//Tester Total Score
			$sql="SELECT SUM(final_score) FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
			$result2=mysql_query($sql,$db);
			$sum_y=mysql_result($result2,0,0);


			//************************************
			// Begining: each choice statistics (R Value and Corrected R Value)
			$mean_variance = $sum_x / $Sample_Size;
			$sql= "SELECT * FROM ".TABLE_PREFIX."tests_results WHERE test_id=$tid ";
			$result4 = mysql_query($sql,$db);
			while ($results =mysql_fetch_array($result4)){
				$sql= "SELECT * FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id=".$question['question_id']."";
				$result5 = mysql_query($sql,$db);
				$answer2 = mysql_fetch_array($result5);
				
				$variance = $variance +(($answer2['score'] - $mean_variance)*($answer2['score'] - $mean_variance));

				$sql= "SELECT SUM(score) FROM ".TABLE_PREFIX."tests_answers WHERE result_id=".$results['result_id']." AND question_id<>".$question['question_id']."";
				$result2=mysql_query($sql,$db);
				$sum_corrected_y= $sum_corrected_y + mysql_result($result2,0,0);
			}


			//R Value 
			if ((($Sample_Size*$sum_xx)-($sum_x*$sum_x))*(($Sample_Size*$sum_yy)-($sum_y*$sum_y))<>0){
				$R_Value[$i]=number_format((($Sample_Size*$sum_xy)-($sum_x*$sum_y))/sqrt( (($Sample_Size*$sum_xx)-($sum_x*$sum_x))*(($Sample_Size*$sum_yy)-($sum_y*$sum_y))   ),3);
			}else{
				$R_Value[$i]=0;
			}

			//Corrected R Value
			if ((($Sample_Size*$sum_xx)-($sum_x*$sum_x))*(($Sample_Size*$sum_corrected_yy)-($sum_corrected_y*$sum_corrected_y))<>0){
				$Corrected_R_Value[$i]=number_format((($Sample_Size*$sum_corrected_xy)-($sum_x*$sum_corrected_y))/sqrt( (($Sample_Size*$sum_xx)-($sum_x*$sum_x))*(($Sample_Size*$sum_corrected_yy)-($sum_corrected_y*$sum_corrected_y))   ),3);
			}else{
				$Corrected_R_Value[$i]=0;
			}

			$ADC = $ADC + $R_Value[$i];
			$arr_sd[$i]=$variance/($Sample_Size-1);
			$sum_variance=$sum_variance + $arr_sd[$i];
			$arr_sd[$i] = number_format(sqrt($arr_sd[$i]),3);
			$variance=0;
			$i++;

			//Ending: each choice statistics (R Value and Corrected R Value)
			//************************************
			
		}
		//Ending: Item analysis
		//************************************
		
		//Formatting Avg P Value, Avg R Value and Reliability
		$AD = number_format($AD / $Total_Item,3);
		$ADC = number_format($ADC / $Total_Item,3);
		$Alpha = number_format(($Total_Item/($Total_Item-1))*(1-($sum_variance/$variance_y)),3);


/******************* Ending of calculate part ****************************/
/******************************************************************/



		//************************************
		//Begining: Analysis Summary Report 
		echo '<br />';
		echo '<table class="data static" summary="" style="width: 95%" rules="cols">';
		echo '<thead>';
		echo '<tr>';
		echo '<th scope="col" width="20%">'._AT('ta_sample_size').'</th>';
		echo '<th scope="col" width="20%">'._AT('ta_total_item').'</th>';
		echo '<th scope="col" width="20%">'._AT('ta_total_score').'</th>';
		echo '<th scope="col" width="20%">'._AT('ta_avg_p_value').'</th>';
		echo '<th scope="col" width="20%">'._AT('ta_avg_r_value').'</th></thead></tr>';
		echo '<tr>';
		echo '<td align="center">'.$Sample_Size.'</td>';
		echo '<td align="center">'.$Total_Item.'</td>';
		echo '<td align="center">'.$Total_Score.'</td>';
		echo '<td align="center">'.$AD.'</td>';
		echo '<td align="center">'.$ADC.'</td></tr>';
		//echo '</table>';
		echo '<tr><th height="1" colspan="5"></th></tr>';
		//echo '<table class="data static" summary="" style="width: 95%" rules="cols">';
		echo '<tr>';
		echo '<thead>';
		echo '<th scope="col" align="center" width="20%">'._AT('ta_max').'</th>';
		echo '<th scope="col" align="center" width="20%">'._AT('ta_min').'</th>';
		echo '<th scope="col" align="center" width="20%">'._AT('ta_mean').'</th>';
		echo '<th scope="col" align="center" width="20%">'._AT('ta_median').'</th>';
		echo '<th scope="col" align="center" width="20%">'._AT('ta_sd').'</th></thead></tr>';
		echo '<tr>';
		echo '<td align="center">'.$Max.'</td>';
		echo '<td align="center">'.$Min.'</td>';
		echo '<td align="center">'.$Mean.'</td>';
		echo '<td align="center">'.$Medium.'</td>';
		echo '<td align="center">'.$SD.'</td></tr>';
		//echo '<tr><td height="1" colspan="5"></td></tr>';
		echo '<table class="data static" summary="" style="width: 50%" rules="cols">';
		echo '<tr><thead>';
		echo '<th scope="col" align="center">'._AT('ta_reliability').'</th></tr>';
		echo '</thead><tr>';
		echo '<td align="center">'.$Alpha.'</td></tr></table><br>';
		//Ending: Analysis Summary Report 
		//************************************


		//************************************
		//Begining: Item Analysis Report 
		echo '<table class="data static" summary="" align="center"  rules="cols" style="width: 95%">';
		echo '<tr><thead>';
		//Header
		echo '<th scope="col">'._AT('ta_item').'</th>';
		echo '<th scope="col">'._AT('ta_question').'</th>';
		echo '<th scope="col">'._AT('ta_weight').'</th>';
		echo '<th scope="col">'._AT('ta_average').'</th>';
		echo '<th scope="col">'._AT('ta_p_value').'</th>';
		echo '<th scope="col">'._AT('ta_r_value').'</th>';
		echo '<th scope="col">'._AT('ta_corrected_r_value').'</th>';
		echo '<th scope="col">'._AT('ta_correct_answer').'</th>';
		for($i = 0; $i< $Total_Choice; $i++) {
			echo '<th scope="col">C'.($i+1).'</th>';
		}
		echo '</thead></tr>';
		//Data
		$sql= "SELECT TQ.*, TQA.* FROM ".TABLE_PREFIX."tests_questions TQ INNER JOIN ".TABLE_PREFIX."tests_questions_assoc TQA USING (question_id) WHERE TQ.course_id=$_SESSION[course_id] AND TQA.test_id=$tid ORDER BY TQA.ordering, TQA.question_id";
		$result = mysql_query($sql,$db);
		$i=1;
		while ($question = mysql_fetch_array($result)){
			if ($question['type']==1){
					for($j=0;$j<=9;$j++){
						if ($question['answer_'.$j]==1){
							$Correct_Answer = $j+1;
							$j=9;
						}
					}
			}else if ($question['type']==2){
					if ($question['answer_0']==1){
							$Correct_Answer = 1;
					}else if ($question['answer_0']==2){
							$Correct_Answer = 2;
					}
			}else if ($question['type']==4){
					$Correct_Answer = "-";

			}else{
				$Correct_Answer = "-";
			}

			
			echo '<tr><td align="right">'.$i.'</td>'; 
			echo '<td align="right">'.$question['question'].'</td>'; 
			echo '<td align="right">'.$question['weight'].'</td>'; 
			echo '<td align="right">'.$P_Value[$i].'</td>'; 
			//echo '<td align="right">'.$arr_sd[$i].'</td>'; 
			echo '<td align="right">'.$Real_P_Value[$i].'</td>'; 
			echo '<td align="right">'.$R_Value[$i].'</td>'; 
			echo '<td align="right">'.$Corrected_R_Value[$i].'</td>'; 
			echo '<td align="right">'.($Correct_Answer).'</td>'; 
			
			for($k = 1; $k<= $Total_Choice; $k++) {
				echo '<td align="right">'.$Q[$i][$k].'<br>('.number_format((($Q[$i][$k]/$Sample_Size)*100),2).'%)</td>'; 
			}
			echo '</tr>';
			echo '<tr><thead><th height="1" colspan="'. ($Total_Choice+8).'"></th></thead></tr>';




			// *** Check Table for keep record ################
			//#########################################################################
			$rs_status = mysql_query("SHOW TABLES LIKE '".TABLE_PREFIX."tests_questions_stat'");
			if (!$rs_status || mysql_num_rows($rs_status) <= 0) {  //if not exist then create it
				$sql="CREATE TABLE AT_tests_questions_stat (question_id mediumint(8) unsigned NOT NULL default '0',stat varchar(5) NOT NULL,  value float(4,3) NOT NULL,  PRIMARY KEY  (`question_id`,`stat`)) ";
				mysql_query($sql,$db);
			}


			//Keep Record Statistic (P Value)
			$sql= "SELECT value FROM ".TABLE_PREFIX."tests_questions_stat WHERE question_id=".$question['question_id']." AND stat='p'";
			$result5 = mysql_query($sql,$db);
			if ($row5 = mysql_fetch_array($result5)) {
				if ($row5[value] < $Real_P_Value[$i]) {
				$sql="UPDATE ".TABLE_PREFIX."tests_questions_stat SET value=".$Real_P_Value[$i]."  WHERE question_id=".$question['question_id']." AND stat='p'";
				mysql_query($sql,$db);
				
				}
			} else { 
					$sql="INSERT INTO ".TABLE_PREFIX."tests_questions_stat VALUES('".$question['question_id']."','p',".$Real_P_Value[$i].")";
					mysql_query($sql,$db);
					
			}

			//Keep Record Statistic (R Value)
			$sql= "SELECT value FROM ".TABLE_PREFIX."tests_questions_stat WHERE question_id=".$question['question_id']." AND stat='r'";
			$result5 = mysql_query($sql,$db);
			if ($row5 = mysql_fetch_array($result5)) {
				if ($row5[value] < $R_Value[$i]) {
					$sql="UPDATE ".TABLE_PREFIX."tests_questions_stat SET value=".$R_Value[$i]."  WHERE question_id=".$question['question_id']." AND stat='r'";
					mysql_query($sql,$db);
					
				}
			} else { 
				$sql="INSERT INTO ".TABLE_PREFIX."tests_questions_stat VALUES('".$question['question_id']."','r',".$R_Value[$i].")";
				mysql_query($sql,$db);
				
				
			}





			$i++;
		}
		echo '</table>';
		//Ending: Item Analysis Report
		//************************************

		//Attribute description
		echo '<br /><table class="data static" summary="" style="width: 95%" rules="cols"><tr></thead><td align="left">';
		echo _AT('ta_footnote');
		echo '</td></tr></table>';


	} else {
		echo '<table cellspacing="1" cellpadding="0" border="0" class="bodyline" summary="" align="center" width = "80%">';
		echo '<tr><th scope="col">&nbsp;&nbsp;&nbsp;&nbsp;</th></tr>';
		echo '<tr><td colspan="'.(3+$num_questions).'" class="row1"><i>'._AT('no_results_available').'.</i></td></tr>';
	}
	
	require(AT_INCLUDE_PATH.'footer.inc.php');
?>
