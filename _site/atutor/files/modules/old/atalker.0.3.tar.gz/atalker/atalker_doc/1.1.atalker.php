<?php
/************************************************************************/
/* ATalker														*/
/************************************************************************/
/* Copyright (c) 2002-2005 by Greg Gay                                                                      */
/* Adaptive Technology Resource Centre / University of Toronto			*/
/* http://atutor.ca														*/
/*																		*/
/* This program is free software. You can redistribute it and/or		*/
/* modify it under the terms of the GNU General Public License			*/
/* as published by the Free Software Foundation.						*/
/************************************************************************/
// $Id: 1.1.atalker.php 5128 2005-07-12 15:56:36Z greg $

require('../common/body_header.inc.php'); ?>

<h2>1.1 Using ATalker</h2>

<p>Users can paste text and read it aloud. Instructors can can save speech to provide audio content. etc.</p>

<?php require('../common/body_footer.inc.php'); ?>
