INSERT INTO `language_text` VALUES ('en', '_module','twitter','Twitter',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','twitter_intro','A quick twitter search module to search real time content related to course.',NOW(),'');
INSERT INTO `language_text` VALUES ('en', '_module','twitter_error','Please enter some query term.',NOW(),'');
