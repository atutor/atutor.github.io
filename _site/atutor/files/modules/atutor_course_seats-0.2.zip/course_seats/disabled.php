<?php
define('AT_INCLUDE_PATH', '../../include/');
require (AT_INCLUDE_PATH.'vitals.inc.php');
require (AT_INCLUDE_PATH.'header.inc.php'); 
?>
<div class="input-form">
<p><strong>Disabled: </strong></p>
</div>
<?php
require (AT_INCLUDE_PATH.'footer.inc.php'); 

?>