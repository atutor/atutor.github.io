
<ul class="social_inline_menu">
	<li class="inlinelist"><a href="<?php echo 'mods/social/profile_picture.php'; ?>"><?php echo _AT('Picture'); ?></a></li>
	<li class="inlinelist"><a href="<?php echo 'mods/social/basic_profile.php'; ?>"><?php echo _AT('basic_profile'); ?></a></li>
	<li class="inlinelist"><a href="<?php echo 'mods/social/edit_profile.php'; ?>"><?php echo _AT('social_profile'); ?></a></li>
</ul>
